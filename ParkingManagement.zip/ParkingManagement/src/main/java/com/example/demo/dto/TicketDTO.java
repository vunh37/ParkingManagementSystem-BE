package com.example.demo.dto;

public class TicketDTO {
	
	private String userName;
	private String userId;
	private long ticketTypeId;
}
